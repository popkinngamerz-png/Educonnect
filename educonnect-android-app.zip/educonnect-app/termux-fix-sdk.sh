#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#  Run this ONLY if termux-build.sh keeps failing at SDK step
#  This is the nuclear fallback using Termux's own packages
# ============================================================
GREEN='\033[0;32m'; BLUE='\033[0;34m'; RED='\033[0;31m'; NC='\033[0m'
info() { echo -e "${BLUE}▶ $1${NC}"; }
ok()   { echo -e "${GREEN}✅ $1${NC}"; }

info "Removing broken SDK download..."
rm -rf "$HOME/android-sdk"
rm -f "$HOME/cmdtools.zip" "$HOME/platform-34.zip" "$HOME/build-tools.zip"

info "Installing android-tools via Termux pkg..."
pkg install android-tools -y

info "Checking what got installed..."
which aapt2 2>/dev/null && ok "aapt2 found" || echo "no aapt2"
which adb   2>/dev/null && ok "adb found"   || echo "no adb"

info "Installing extra build deps..."
pkg install gradle -y 2>/dev/null || true

echo ""
echo -e "${GREEN}Now paste this and press Enter, then run the build again:${NC}"
echo ""
echo "  bash termux-build.sh"
