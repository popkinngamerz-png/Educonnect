#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#  EduConnect APK Builder — Termux Edition v4
#  Fixes: uses sdkmanager correctly with Termux Java flags
# ============================================================
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
info() { echo -e "${BLUE}▶ $1${NC}"; }
ok()   { echo -e "${GREEN}✅ $1${NC}"; }
warn() { echo -e "${YELLOW}⚠️  $1${NC}"; }
fail() { echo -e "${RED}❌ $1${NC}"; echo -e "${RED}   Fix: $2${NC}"; exit 1; }

echo -e "${BLUE}"
echo "╔══════════════════════════════════════╗"
echo "║   EduConnect APK Builder (Termux)    ║"
echo "╚══════════════════════════════════════╝"
echo -e "${NC}"

# ── 1. npm fix ───────────────────────────────────────────────
info "Fixing npm permissions..."
mkdir -p "$HOME/.npm-global"
npm config set prefix "$HOME/.npm-global"
export PATH="$HOME/.npm-global/bin:$PATH"
grep -q 'npm-global' "$HOME/.bashrc" 2>/dev/null || \
  echo 'export PATH="$HOME/.npm-global/bin:$PATH"' >> "$HOME/.bashrc"
ok "npm permissions fixed"

# ── 2. Check tools ───────────────────────────────────────────
command -v node >/dev/null 2>&1 || fail "Node.js missing" "pkg install nodejs-lts"
ok "Node $(node -v)"
command -v java >/dev/null 2>&1 || fail "Java missing" "pkg install openjdk-17"
ok "Java $(java -version 2>&1 | head -1 | cut -d'"' -f2)"
command -v unzip >/dev/null 2>&1 || { pkg install unzip -y; }
command -v curl  >/dev/null 2>&1 || { pkg install curl  -y; }

# ── 3. Android SDK via cmdline-tools + sdkmanager ────────────
SDK="$HOME/android-sdk"
TOOLS="$SDK/cmdline-tools/latest"
export ANDROID_HOME="$SDK"
export ANDROID_SDK_ROOT="$SDK"
export PATH="$TOOLS/bin:$SDK/platform-tools:$SDK/build-tools/34.0.0:$PATH"

# Persist env
grep -q 'ANDROID_HOME' "$HOME/.bashrc" 2>/dev/null || cat >> "$HOME/.bashrc" << 'ENV'
export ANDROID_HOME="$HOME/android-sdk"
export ANDROID_SDK_ROOT="$HOME/android-sdk"
export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$ANDROID_HOME/build-tools/34.0.0:$PATH"
ENV

if [ ! -f "$TOOLS/bin/sdkmanager" ]; then
  info "Downloading Android command-line tools..."
  mkdir -p "$SDK/cmdline-tools"
  curl -L --fail \
    "https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip" \
    -o "$HOME/cmdtools.zip" --progress-bar \
    || fail "Download failed" "Check internet and try again"

  info "Extracting..."
  unzip -q "$HOME/cmdtools.zip" -d "$HOME/cmdtools-tmp/"
  rm -f "$HOME/cmdtools.zip"

  # Google puts it inside a 'cmdline-tools' subfolder
  if [ -d "$HOME/cmdtools-tmp/cmdline-tools" ]; then
    mv "$HOME/cmdtools-tmp/cmdline-tools" "$TOOLS"
  else
    mv "$HOME/cmdtools-tmp" "$TOOLS"
  fi
  rm -rf "$HOME/cmdtools-tmp"
  ok "Command-line tools ready"
fi

# sdkmanager needs this Java flag in Termux or it silently fails
export JAVA_TOOL_OPTIONS="-Dcom.android.sdklib.toolsdir=$TOOLS"
SDKMANAGER="$TOOLS/bin/sdkmanager --sdk_root=$SDK"

if [ ! -f "$SDK/platforms/android-34/android.jar" ]; then
  info "Accepting SDK licenses (Termux-compatible method)..."
  # The normal 'yes |' pipe breaks in Termux — use printf instead
  printf 'y\ny\ny\ny\ny\ny\ny\n' | $SDKMANAGER --licenses > /dev/null 2>&1 || true

  info "Installing platform-tools..."
  $SDKMANAGER "platform-tools" > /dev/null 2>&1 \
    || warn "platform-tools install had warnings (usually ok)"

  info "Installing android-34 platform (~80MB)..."
  $SDKMANAGER "platforms;android-34" 2>&1 | grep -v "^Info:" | tail -5 \
    || fail "platform install failed" "Run: bash termux-fix-sdk.sh"

  info "Installing build-tools 34.0.0 (~50MB)..."
  $SDKMANAGER "build-tools;34.0.0" 2>&1 | grep -v "^Info:" | tail -5 \
    || fail "build-tools install failed" "Run: bash termux-fix-sdk.sh"

  ok "Android SDK components installed"
else
  ok "Android SDK already set up"
fi

# ── 4. npm install ───────────────────────────────────────────
info "Installing npm packages..."
npm install --no-fund --no-audit 2>&1 | grep -v "^npm warn" | tail -4
ok "Packages installed"

# ── 5. Capacitor setup ───────────────────────────────────────
info "Adding Capacitor Android platform..."
if [ ! -d "android" ]; then
  npx cap add android 2>&1 | tail -4
  ok "Android project created"
else
  ok "android/ exists — skipping"
fi

info "Syncing web assets into Android..."
npx cap sync android 2>&1 | tail -3
ok "Synced"

# ── 6. Write Gradle config ───────────────────────────────────
info "Writing Gradle config..."

echo "sdk.dir=$SDK" > android/local.properties

cat > android/gradle.properties << 'GPROPS'
org.gradle.jvmargs=-Xmx768m -XX:MaxMetaspaceSize=256m -Dfile.encoding=UTF-8
org.gradle.daemon=false
org.gradle.parallel=false
android.useAndroidX=true
android.enableJetifier=true
GPROPS

ok "Gradle configured"

# ── 7. Build ─────────────────────────────────────────────────
info "Building APK — keep screen ON, takes 5-15 min..."
cd android
chmod +x gradlew

export GRADLE_USER_HOME="$HOME/.gradle"
export JAVA_OPTS="-Xmx768m"

./gradlew assembleDebug --no-daemon --quiet 2>&1 | tail -20

cd ..

# ── 8. Result ────────────────────────────────────────────────
APK="android/app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK" ]; then
  SIZE=$(du -sh "$APK" | cut -f1)
  cp "$APK" "$HOME/storage/downloads/EduConnect.apk" 2>/dev/null \
    && ok "Saved to Downloads/EduConnect.apk" \
    || warn "Could not reach Downloads — run termux-setup-storage first"

  echo -e "${GREEN}"
  echo "╔══════════════════════════════════════╗"
  echo "║      ✅ BUILD SUCCESSFUL! 🎉          ║"
  echo "╠══════════════════════════════════════╣"
  echo "║  APK: ~/storage/downloads/EduConnect.apk"
  echo "║  Size: $SIZE"
  echo "╠══════════════════════════════════════╣"
  echo "║  → Open Files app → Downloads        ║"
  echo "║  → Tap EduConnect.apk → Install      ║"
  echo "╚══════════════════════════════════════╝"
  echo -e "${NC}"
else
  echo -e "${RED}❌ Build failed. Running again with full output:${NC}"
  cd android && ./gradlew assembleDebug --no-daemon --stacktrace 2>&1 | tail -60
  exit 1
fi
