// ============================================================
// EduConnect Shared UI Helpers
// ============================================================
function bottomNav(active) {
  const items = [
    {id:'dashboard', icon:'dashboard',  label:'Home'},
    {id:'homework',  icon:'assignment', label:'Work'},
    {id:'notices',   icon:'campaign',   label:'Board'},
    {id:'doubts',    icon:'help',       label:'Doubts'},
  ];
  return `<nav class="fixed bottom-0 left-0 w-full flex justify-around items-center bg-white border-t border-gray-200 h-[68px] z-50 shadow-lg">
    ${items.map(i=>`<button onclick="navigate('${i.id}')" class="flex flex-col items-center justify-center gap-0.5 flex-1 h-full transition-all ${active===i.id?'text-blue-600':'text-gray-500'}">
      <span class="material-symbols-outlined text-[22px]" style="${active===i.id?"font-variation-settings:'FILL' 1":""}">${i.icon}</span>
      <span class="text-[10px] font-medium">${i.label}</span>
    </button>`).join('')}
  </nav>`;
}

function topBar(title, back=false, right='') {
  return `<header class="sticky top-0 z-40 bg-white border-b border-gray-200 flex items-center px-4 h-14 gap-2 shadow-sm">
    ${back?`<button onclick="navigate('dashboard')" class="p-2 rounded-full hover:bg-gray-100"><span class="material-symbols-outlined text-gray-600 text-[22px]">arrow_back</span></button>`:''}
    <span class="flex-1 font-semibold text-[17px] text-gray-900">${title}</span>
    ${right}
  </header>`;
}

function toast(msg, type='ok') {
  const t = document.createElement('div');
  t.className = `fixed top-5 left-1/2 -translate-x-1/2 z-[200] px-5 py-3 rounded-2xl shadow-xl text-sm font-semibold transition-all ${type==='ok'?'bg-green-600 text-white':'bg-red-600 text-white'}`;
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(()=>t.remove(), 2600);
}

function modal(id, title, body, footer) {
  return `<div id="${id}" class="hidden fixed inset-0 bg-black/50 z-[100] flex items-end">
    <div class="bg-white w-full rounded-t-3xl p-5 shadow-2xl max-h-[90vh] overflow-y-auto">
      <div class="flex items-center justify-between mb-4">
        <h3 class="font-bold text-gray-900 text-base">${title}</h3>
        <button onclick="document.getElementById('${id}').classList.add('hidden')" class="p-1 rounded-full hover:bg-gray-100">
          <span class="material-symbols-outlined text-gray-500">close</span></button>
      </div>
      ${body}
      <div class="flex gap-2 mt-4">${footer}</div>
    </div>
  </div>`;
}

function inputField(id, type, placeholder, icon, extra='') {
  return `<div class="relative">
    <span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-[18px]">${icon}</span>
    <input id="${id}" type="${type}" placeholder="${placeholder}" ${extra}
      class="w-full h-12 pl-10 pr-4 border border-gray-200 rounded-2xl bg-gray-50 text-sm focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none transition-all"/>
  </div>`;
}

window.bottomNav  = bottomNav;
window.topBar     = topBar;
window.toast      = toast;
window.modal      = modal;
window.inputField = inputField;
