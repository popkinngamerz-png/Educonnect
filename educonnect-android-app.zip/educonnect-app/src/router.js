// ============================================================
// EduConnect SPA Router
// ============================================================
const Router = {
  routes: {}, after: {},
  register(name, fn)   { this.routes[name] = fn; },
  afterRender(name,fn) { this.after[name]  = fn; },
  navigate(screen, params={}) {
    const s = DB.getSession();
    if (!['login','register'].includes(screen) && !s) { this.navigate('login'); return; }
    const fn = this.routes[screen];
    if (!fn) return;
    document.getElementById('app').innerHTML = fn(params, s);
    window.scrollTo(0,0);
    if (this.after[screen]) this.after[screen](params, s);
  }
};
window.Router  = Router;
window.navigate = (s,p) => Router.navigate(s,p);
