// ============================================================
// EduConnect — All App Screens
// ============================================================

// ─── LOGIN ────────────────────────────────────────────────────
Router.register('login', () => `
<div class="min-h-screen bg-blue-700 flex flex-col items-center justify-center p-5">
  <div class="w-full max-w-sm bg-white rounded-3xl p-6 shadow-2xl">
    <div class="flex flex-col items-center mb-6">
      <div class="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mb-3">
        <span class="material-symbols-outlined text-blue-700 text-[36px]" style="font-variation-settings:'FILL' 1">school</span>
      </div>
      <h1 class="text-2xl font-bold text-gray-900">EduConnect</h1>
      <p class="text-sm text-gray-500 mt-1 text-center">Classroom Management Platform</p>
    </div>

    <!-- Role selector -->
    <div class="flex bg-gray-100 rounded-2xl p-1 mb-4" id="role-bar">
      ${['teacher','student','admin'].map((r,i)=>`
        <button id="rb-${r}" onclick="setRole('${r}',${i})"
          class="flex-1 py-2 rounded-xl text-sm font-medium transition-all ${r==='teacher'?'bg-white shadow text-blue-700':'text-gray-500'}">${r[0].toUpperCase()+r.slice(1)}</button>`).join('')}
    </div>

    <!-- Admin demo hint -->
    <div id="admin-hint" class="hidden mb-3 p-3 bg-blue-50 rounded-2xl border border-blue-200 text-xs text-blue-800 flex gap-2 items-start">
      <span class="material-symbols-outlined text-[14px] mt-0.5">info</span>
      <span>Demo: <b>admin@edu.app</b> / <b>admin123</b></span>
    </div>

    <div class="space-y-3">
      ${inputField('f-email','text','Email or username','alternate_email')}
      <div class="relative">
        <span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-[18px]">lock</span>
        <input id="f-pass" type="password" placeholder="Password"
          class="w-full h-12 pl-10 pr-11 border border-gray-200 rounded-2xl bg-gray-50 text-sm focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none transition-all"/>
        <button onclick="togglePass()" class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-700">
          <span class="material-symbols-outlined text-[18px]" id="eye-icon">visibility</span></button>
      </div>
      <button onclick="doLogin()"
        class="w-full h-12 bg-blue-700 text-white font-bold rounded-2xl hover:bg-blue-800 active:scale-95 transition-all flex items-center justify-center gap-2 shadow-md">
        <span class="material-symbols-outlined text-[18px]">login</span> Sign In
      </button>
    </div>

    <!-- Quick demo -->
    <div class="mt-5 pt-4 border-t border-gray-100">
      <p class="text-xs text-gray-400 text-center mb-2">Quick demo login</p>
      <div class="flex gap-2">
        ${[['Admin','admin@edu.app','admin123'],['Teacher','teacher@edu.app','teach123'],['Student','student@edu.app','study123']].map(([l,e,p])=>`
          <button onclick="quickLogin('${e}','${p}')"
            class="flex-1 py-2 text-[11px] font-semibold rounded-xl bg-gray-100 text-gray-700 hover:bg-blue-100 hover:text-blue-700 transition-all">${l}</button>`).join('')}
      </div>
    </div>

    <p class="text-center text-xs text-gray-500 mt-4">New student? <button onclick="navigate('register')" class="text-blue-600 font-semibold hover:underline">Register here</button></p>
  </div>
</div>`);

Router.afterRender('login', () => {
  window._role = 'teacher';
  window.setRole = (role, idx) => {
    window._role = role;
    document.querySelectorAll('#role-bar button').forEach(b=>b.className=b.className.replace('bg-white shadow text-blue-700','text-gray-500'));
    const btn = document.getElementById('rb-'+role);
    btn.className = btn.className.replace('text-gray-500','bg-white shadow text-blue-700');
    document.getElementById('admin-hint').classList.toggle('hidden', role!=='admin');
    const fills = {admin:['admin@edu.app','admin123'],teacher:['teacher@edu.app','teach123'],student:['student@edu.app','study123']};
    document.getElementById('f-email').value = fills[role][0];
    document.getElementById('f-pass').value  = fills[role][1];
  };
  window.togglePass = () => {
    const p=document.getElementById('f-pass'), e=document.getElementById('eye-icon');
    p.type = p.type==='password'?'text':'password';
    e.textContent = p.type==='password'?'visibility':'visibility_off';
  };
  window.quickLogin = (email,pass) => { document.getElementById('f-email').value=email; document.getElementById('f-pass').value=pass; doLogin(); };
  window.doLogin = () => {
    const email=document.getElementById('f-email').value.trim();
    const pass =document.getElementById('f-pass').value.trim();
    if(!email||!pass){toast('Enter your credentials','err');return;}
    const user=DB.login(email,pass);
    if(!user){toast('Wrong credentials — try the demo buttons','err');return;}
    DB.setSession(user);
    navigate('dashboard');
  };
});

// ─── REGISTER ─────────────────────────────────────────────────
Router.register('register', ()=>`
<div class="min-h-screen bg-gray-50 pb-8">
  ${topBar('Student Registration', true)}
  <div class="p-4">
    <div class="bg-white rounded-3xl p-5 shadow-sm border border-gray-100 space-y-3">
      <p class="text-sm text-gray-500 mb-1">Create your EduConnect student account</p>
      ${inputField('r-name','text','Full name','person')}
      ${inputField('r-email','email','Email address','alternate_email')}
      ${inputField('r-phone','tel','Phone number','call')}
      <div class="relative">
        <span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-[18px]">class</span>
        <select id="r-class" class="w-full h-12 pl-10 pr-4 border border-gray-200 rounded-2xl bg-gray-50 text-sm focus:border-blue-500 outline-none appearance-none">
          <option value="">Select your class</option>
          ${['8A','8B','9A','9B','10A','10B','11A','11B','12A','12B'].map(c=>`<option value="${c}">${c}</option>`).join('')}
        </select>
      </div>
      ${inputField('r-pass','password','Create password (min 6 chars)','lock')}
      <button onclick="doRegister()" class="w-full h-12 bg-blue-700 text-white font-bold rounded-2xl hover:bg-blue-800 active:scale-95 transition-all flex items-center justify-center gap-2 shadow-md">
        <span class="material-symbols-outlined text-[18px]">how_to_reg</span> Create Account
      </button>
    </div>
    <p class="text-center text-sm text-gray-500 mt-4">Already have an account? <button onclick="navigate('login')" class="text-blue-600 font-semibold">Sign in</button></p>
  </div>
</div>`);
Router.afterRender('register', ()=>{
  window.doRegister = () => {
    const name  = document.getElementById('r-name').value.trim();
    const email = document.getElementById('r-email').value.trim();
    const phone = document.getElementById('r-phone').value.trim();
    const cls   = document.getElementById('r-class').value;
    const pass  = document.getElementById('r-pass').value;
    if(!name||!email||!cls||!pass){toast('Fill all fields','err');return;}
    if(pass.length<6){toast('Password min 6 characters','err');return;}
    DB.addStudent({name,email,phone,class:cls,password:pass});
    toast('Account created! Please log in.');
    setTimeout(()=>navigate('login'),1200);
  };
});

// ─── DASHBOARD ────────────────────────────────────────────────
Router.register('dashboard', (_,s) => {
  const hw      = DB.get('homework');
  const pending = hw.filter(h=>h.status==='Pending').length;
  const notices = DB.get('notices');
  const doubts  = DB.get('doubts').filter(d=>!d.answered).length;
  const isAdmin = s.role==='admin';
  const isSta   = s.role==='admin'||s.role==='teacher';
  return `
<div class="min-h-screen bg-gray-50 pb-20">
  <!-- Hero header -->
  <div class="bg-blue-700 px-5 pt-12 pb-6">
    <div class="flex items-center gap-3">
      <div class="flex-1">
        <p class="text-blue-200 text-sm">Welcome back 👋</p>
        <h1 class="text-white text-xl font-bold mt-0.5">${s.name}</h1>
        <span class="inline-block mt-1 px-3 py-0.5 rounded-full bg-blue-600 text-blue-100 text-xs font-medium capitalize">${s.role}</span>
      </div>
      <div class="w-12 h-12 rounded-2xl bg-blue-600 flex items-center justify-center">
        <span class="material-symbols-outlined text-white text-[26px]" style="font-variation-settings:'FILL' 1">account_circle</span>
      </div>
    </div>
    <!-- Stats -->
    <div class="grid grid-cols-3 gap-3 mt-5">
      ${[['Assignments',hw.length,'assignment','blue'],['Notices',notices.length,'campaign','green'],['Open Doubts',doubts,'help','orange']].map(([l,v,ic,c])=>`
        <div class="bg-white/15 rounded-2xl p-3 text-center">
          <p class="text-white font-bold text-xl">${v}</p>
          <p class="text-blue-100 text-[10px] mt-0.5">${l}</p>
        </div>`).join('')}
    </div>
  </div>

  <div class="p-4 space-y-4">
    <!-- Quick Actions -->
    <h2 class="font-bold text-gray-800 text-sm">Quick Actions</h2>
    <div class="grid grid-cols-2 gap-3">
      <button onclick="navigate('homework')" class="bg-blue-700 text-white rounded-2xl p-4 flex flex-col items-start gap-2 active:scale-95 transition-all shadow-md">
        <span class="material-symbols-outlined text-[28px]" style="font-variation-settings:'FILL' 1">assignment</span>
        <div><p class="font-bold text-sm">Homework</p><p class="text-xs text-blue-200">${pending} pending</p></div>
      </button>
      <button onclick="navigate('notices')" class="bg-green-700 text-white rounded-2xl p-4 flex flex-col items-start gap-2 active:scale-95 transition-all shadow-md">
        <span class="material-symbols-outlined text-[28px]" style="font-variation-settings:'FILL' 1">campaign</span>
        <div><p class="font-bold text-sm">Notice Board</p><p class="text-xs text-green-200">Latest updates</p></div>
      </button>
      <button onclick="navigate('doubts')" class="bg-white border border-gray-200 rounded-2xl p-4 flex flex-col items-start gap-2 active:scale-95 transition-all shadow-sm">
        <span class="material-symbols-outlined text-blue-700 text-[28px]" style="font-variation-settings:'FILL' 1">help</span>
        <div><p class="font-bold text-sm text-gray-900">Doubt Section</p><p class="text-xs text-gray-500">${doubts} unanswered</p></div>
      </button>
      ${isAdmin
        ? `<button onclick="navigate('teachers')" class="bg-orange-50 border border-orange-200 rounded-2xl p-4 flex flex-col items-start gap-2 active:scale-95 transition-all">
            <span class="material-symbols-outlined text-orange-600 text-[28px]" style="font-variation-settings:'FILL' 1">manage_accounts</span>
            <div><p class="font-bold text-sm text-gray-900">Manage Teachers</p><p class="text-xs text-gray-500">Admin only</p></div>
           </button>`
        : `<button onclick="navigate('register')" class="bg-purple-50 border border-purple-200 rounded-2xl p-4 flex flex-col items-start gap-2 active:scale-95 transition-all">
            <span class="material-symbols-outlined text-purple-600 text-[28px]" style="font-variation-settings:'FILL' 1">how_to_reg</span>
            <div><p class="font-bold text-sm text-gray-900">Register</p><p class="text-xs text-gray-500">New students</p></div>
           </button>`}
    </div>

    <!-- Recent Notices -->
    <div>
      <div class="flex items-center justify-between mb-2">
        <h2 class="font-bold text-gray-800 text-sm">Recent Notices</h2>
        <button onclick="navigate('notices')" class="text-xs text-blue-600 font-semibold">See all →</button>
      </div>
      ${notices.slice(0,3).map(n=>`
        <div class="bg-white border border-gray-100 rounded-2xl p-3 mb-2 flex gap-3 shadow-sm">
          <div class="w-9 h-9 rounded-xl bg-blue-100 flex items-center justify-center flex-shrink-0">
            <span class="material-symbols-outlined text-blue-700 text-[18px]" style="font-variation-settings:'FILL' 1">campaign</span></div>
          <div class="flex-1 min-w-0">
            <p class="font-semibold text-gray-900 text-sm truncate">${n.title}</p>
            <p class="text-xs text-gray-500">${n.category} · ${n.date}</p>
          </div>
        </div>`).join('')}
    </div>

    <!-- Logout -->
    <button onclick="DB.clearSession();navigate('login');"
      class="w-full h-11 border-2 border-red-200 text-red-600 rounded-2xl text-sm font-bold hover:bg-red-50 active:scale-95 transition-all flex items-center justify-center gap-2">
      <span class="material-symbols-outlined text-[18px]">logout</span> Sign Out
    </button>
  </div>
  ${bottomNav('dashboard')}
</div>`;
});

// ─── HOMEWORK ─────────────────────────────────────────────────
Router.register('homework', (_,s) => {
  const canCreate = s.role==='admin'||s.role==='teacher';
  return `
<div class="min-h-screen bg-gray-50 pb-24">
  ${topBar('Homework Assignments', false, canCreate
    ? `<button onclick="document.getElementById('hw-modal').classList.remove('hidden')" class="ml-auto bg-blue-700 text-white text-xs font-bold px-3 py-1.5 rounded-xl flex items-center gap-1">
        <span class="material-symbols-outlined text-[14px]">add</span>New</button>` : '')}

  <!-- Filter chips -->
  <div class="flex gap-2 px-4 pt-3 pb-2 overflow-x-auto" style="scrollbar-width:none">
    ${['All','Pending','Submitted'].map((f,i)=>`
      <button onclick="filterHW('${f}')" id="hf-${f}"
        class="whitespace-nowrap px-4 py-1.5 rounded-full text-xs font-semibold transition-all ${i===0?'bg-blue-700 text-white':'bg-white border border-gray-200 text-gray-600'}">${f}</button>`).join('')}
  </div>

  <div class="px-4 space-y-3 pb-4" id="hw-list">
    ${DB.get('homework').map(hwCard).join('')}
  </div>

  ${modal('hw-modal','New Assignment',`
    <div class="space-y-3">
      ${inputField('hw-sub','text','Subject (e.g. Mathematics)','menu_book')}
      ${inputField('hw-title','text','Assignment title','title')}
      ${inputField('hw-class','text','Class (e.g. 10A)','class')}
      <input id="hw-due" type="date" class="w-full h-12 px-4 border border-gray-200 rounded-2xl bg-gray-50 text-sm focus:border-blue-500 outline-none"/>
      <textarea id="hw-desc" rows="2" placeholder="Description (optional)" class="w-full px-4 py-3 border border-gray-200 rounded-2xl bg-gray-50 text-sm focus:border-blue-500 outline-none resize-none"></textarea>
    </div>`,
    `<button onclick="document.getElementById('hw-modal').classList.add('hidden')" class="flex-1 h-11 border border-gray-200 rounded-2xl text-sm text-gray-600">Cancel</button>
     <button onclick="saveHW()" class="flex-1 h-11 bg-blue-700 text-white font-bold rounded-2xl text-sm">Publish</button>`)}

  ${bottomNav('homework')}
</div>`;
});

function hwCard(h) {
  const p = h.status==='Pending';
  return `<div class="bg-white border border-gray-100 rounded-2xl p-4 shadow-sm">
    <div class="flex items-start gap-3">
      <div class="w-10 h-10 rounded-xl ${p?'bg-orange-100':'bg-green-100'} flex items-center justify-center flex-shrink-0">
        <span class="material-symbols-outlined text-[20px] ${p?'text-orange-600':'text-green-600'}" style="font-variation-settings:'FILL' 1">assignment</span></div>
      <div class="flex-1 min-w-0">
        <p class="font-bold text-gray-900 text-sm">${h.title}</p>
        <p class="text-xs text-gray-500">${h.subject} · Class ${h.class}</p>
        <p class="text-xs text-gray-600 mt-1 leading-relaxed">${h.description}</p>
      </div>
      <span class="px-2 py-0.5 rounded-full text-[10px] font-bold flex-shrink-0 ${p?'bg-orange-100 text-orange-700':'bg-green-100 text-green-700'}">${h.status}</span>
    </div>
    <div class="flex items-center justify-between mt-3 pt-2 border-t border-gray-100">
      <span class="text-xs text-gray-500 flex items-center gap-1">
        <span class="material-symbols-outlined text-[13px]">event</span>Due: ${h.dueDate}</span>
      ${p?`<button onclick="submitHW(${h.id})" class="text-xs font-bold text-blue-700 border border-blue-200 px-3 py-1 rounded-full hover:bg-blue-50 active:scale-95 transition-all">Submit ✓</button>`:''}
    </div>
  </div>`;
}

Router.afterRender('homework', () => {
  window.filterHW = (f) => {
    ['All','Pending','Submitted'].forEach(x=>{
      const b=document.getElementById('hf-'+x);
      b.className=b.className.replace('bg-blue-700 text-white','bg-white border border-gray-200 text-gray-600');
    });
    const sel=document.getElementById('hf-'+f);
    sel.className=sel.className.replace('bg-white border border-gray-200 text-gray-600','bg-blue-700 text-white');
    const all=DB.get('homework');
    document.getElementById('hw-list').innerHTML=(f==='All'?all:all.filter(h=>h.status===f)).map(hwCard).join('');
  };
  window.saveHW = () => {
    const sub=document.getElementById('hw-sub').value.trim();
    const tit=document.getElementById('hw-title').value.trim();
    const cls=document.getElementById('hw-class').value.trim();
    const due=document.getElementById('hw-due').value;
    const dsc=document.getElementById('hw-desc').value.trim();
    if(!sub||!tit||!due){toast('Subject, title and date required','err');return;}
    DB.addHomework({subject:sub,title:tit,class:cls||'All',dueDate:due,description:dsc,status:'Pending'});
    toast('Assignment published!');
    document.getElementById('hw-modal').classList.add('hidden');
    navigate('homework');
  };
  window.submitHW = (id) => { DB.submitHomework(id); toast('Submitted!'); navigate('homework'); };
});

// ─── NOTICES ──────────────────────────────────────────────────
Router.register('notices', (_,s) => {
  const canPost = s.role==='admin'||s.role==='teacher';
  return `
<div class="min-h-screen bg-gray-50 pb-24">
  ${topBar('Notice Board')}
  <div class="flex gap-2 px-4 pt-3 pb-2 overflow-x-auto" style="scrollbar-width:none">
    ${['All','Academic','Events','Sports','General'].map((f,i)=>`
      <button onclick="filterNC('${f}')" id="nf-${f}"
        class="whitespace-nowrap px-4 py-1.5 rounded-full text-xs font-semibold transition-all ${i===0?'bg-green-700 text-white':'bg-white border border-gray-200 text-gray-600'}">${f}</button>`).join('')}
  </div>

  <div class="px-4 space-y-3" id="nc-list">
    ${DB.get('notices').map(noticeCard).join('')}
  </div>

  ${canPost?`
  <button onclick="document.getElementById('nc-modal').classList.remove('hidden')"
    class="fixed bottom-[84px] right-4 w-14 h-14 bg-green-700 text-white rounded-2xl shadow-xl flex items-center justify-center active:scale-95 transition-all z-40">
    <span class="material-symbols-outlined">edit</span>
  </button>
  ${modal('nc-modal','Post Notice',`
    <div class="space-y-3">
      ${inputField('nc-title','text','Notice title','title')}
      <select id="nc-cat" class="w-full h-12 px-4 border border-gray-200 rounded-2xl bg-gray-50 text-sm focus:border-blue-500 outline-none appearance-none">
        ${['Academic','Events','Sports','General'].map(c=>`<option value="${c}">${c}</option>`).join('')}
      </select>
      <textarea id="nc-body" rows="4" placeholder="Notice content..." class="w-full px-4 py-3 border border-gray-200 rounded-2xl bg-gray-50 text-sm focus:border-blue-500 outline-none resize-none"></textarea>
    </div>`,
    `<button onclick="document.getElementById('nc-modal').classList.add('hidden')" class="flex-1 h-11 border border-gray-200 rounded-2xl text-sm text-gray-600">Cancel</button>
     <button onclick="saveNotice()" class="flex-1 h-11 bg-green-700 text-white font-bold rounded-2xl text-sm">Post</button>`
  )}`:''}

  ${bottomNav('notices')}
</div>`;
});

function noticeCard(n) {
  const cats={Academic:'bg-blue-100 text-blue-800',Events:'bg-green-100 text-green-800',Sports:'bg-orange-100 text-orange-800',General:'bg-gray-100 text-gray-700'};
  const cc=cats[n.category]||cats.General;
  return `<div class="bg-white border ${n.pinned?'border-blue-300':'border-gray-100'} rounded-2xl p-4 shadow-sm">
    <div class="flex items-start gap-2 mb-2">
      ${n.pinned?'<span class="material-symbols-outlined text-blue-600 text-[16px] mt-0.5" style="font-variation-settings:\'FILL\' 1">push_pin</span>':''}
      <span class="px-2 py-0.5 rounded-full text-[10px] font-bold ${cc}">${n.category}</span>
    </div>
    <h3 class="font-bold text-gray-900 text-sm mb-1">${n.title}</h3>
    <p class="text-xs text-gray-600 leading-relaxed">${n.body}</p>
    <div class="flex items-center gap-1 mt-3 pt-2 border-t border-gray-100">
      <span class="material-symbols-outlined text-[12px] text-gray-400">person</span>
      <span class="text-[11px] text-gray-500">${n.author}</span>
      <span class="text-[11px] text-gray-400 ml-auto">${n.date}</span>
    </div>
  </div>`;
}

Router.afterRender('notices', (_,s) => {
  window.filterNC = (f) => {
    ['All','Academic','Events','Sports','General'].forEach(x=>{
      const b=document.getElementById('nf-'+x);
      if(!b)return;
      b.className=b.className.replace('bg-green-700 text-white','bg-white border border-gray-200 text-gray-600');
    });
    const sel=document.getElementById('nf-'+f);
    if(sel) sel.className=sel.className.replace('bg-white border border-gray-200 text-gray-600','bg-green-700 text-white');
    const all=DB.get('notices');
    document.getElementById('nc-list').innerHTML=(f==='All'?all:all.filter(n=>n.category===f)).map(noticeCard).join('');
  };
  window.saveNotice = () => {
    const title=document.getElementById('nc-title').value.trim();
    const cat  =document.getElementById('nc-cat').value;
    const body =document.getElementById('nc-body').value.trim();
    if(!title||!body){toast('Title and content required','err');return;}
    DB.addNotice({title,category:cat,body,author:s.name,pinned:false});
    toast('Notice posted!');
    document.getElementById('nc-modal').classList.add('hidden');
    navigate('notices');
  };
});

// ─── DOUBTS ───────────────────────────────────────────────────
Router.register('doubts', (_,s) => {
  const isTA = s.role==='admin'||s.role==='teacher';
  return `
<div class="min-h-screen bg-gray-50 pb-24">
  ${topBar('Doubt Section', false,
    `<button onclick="document.getElementById('dbt-modal').classList.remove('hidden')"
      class="ml-auto bg-blue-700 text-white text-xs font-bold px-3 py-1.5 rounded-xl flex items-center gap-1">
      <span class="material-symbols-outlined text-[14px]">add</span>Ask</button>`)}

  <div class="flex gap-2 px-4 pt-3 pb-2 overflow-x-auto" style="scrollbar-width:none">
    ${['All','Unanswered','Answered'].map((f,i)=>`
      <button onclick="filterDbt('${f}')" id="df-${f}"
        class="whitespace-nowrap px-4 py-1.5 rounded-full text-xs font-semibold transition-all ${i===0?'bg-blue-700 text-white':'bg-white border border-gray-200 text-gray-600'}">${f}</button>`).join('')}
  </div>

  <div class="px-4 space-y-3 pb-4" id="dbt-list">
    ${DB.get('doubts').map(d=>doubtCard(d,isTA,s)).join('')}
  </div>

  ${modal('dbt-modal','Ask a Doubt',`
    <div class="space-y-3">
      ${inputField('dbt-sub','text','Subject (e.g. Mathematics)','menu_book')}
      <textarea id="dbt-q" rows="3" placeholder="Write your doubt clearly..." class="w-full px-4 py-3 border border-gray-200 rounded-2xl bg-gray-50 text-sm focus:border-blue-500 outline-none resize-none"></textarea>
    </div>`,
    `<button onclick="document.getElementById('dbt-modal').classList.add('hidden')" class="flex-1 h-11 border border-gray-200 rounded-2xl text-sm text-gray-600">Cancel</button>
     <button onclick="saveDbt()" class="flex-1 h-11 bg-blue-700 text-white font-bold rounded-2xl text-sm">Submit</button>`)}

  ${modal('ans-modal','Post Answer',`
    <p id="ans-preview" class="text-xs text-gray-600 bg-gray-50 rounded-xl p-3 mb-2 leading-relaxed"></p>
    <input type="hidden" id="ans-id"/>
    <textarea id="ans-text" rows="3" placeholder="Write your answer..." class="w-full px-4 py-3 border border-gray-200 rounded-2xl bg-gray-50 text-sm focus:border-blue-500 outline-none resize-none"></textarea>`,
    `<button onclick="document.getElementById('ans-modal').classList.add('hidden')" class="flex-1 h-11 border border-gray-200 rounded-2xl text-sm text-gray-600">Cancel</button>
     <button onclick="postAnswer()" class="flex-1 h-11 bg-blue-700 text-white font-bold rounded-2xl text-sm">Post Answer</button>`)}

  ${bottomNav('doubts')}
</div>`;
});

function doubtCard(d, isTA, s) {
  return `<div class="bg-white border border-gray-100 rounded-2xl p-4 shadow-sm">
    <div class="flex items-start gap-3">
      <div class="w-9 h-9 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
        <span class="material-symbols-outlined text-blue-700 text-[18px]" style="font-variation-settings:'FILL' 1">person</span></div>
      <div class="flex-1 min-w-0">
        <div class="flex items-center gap-2 flex-wrap">
          <p class="text-xs font-bold text-gray-900">${d.studentName}</p>
          <span class="px-2 py-0.5 rounded-full text-[10px] font-bold ${d.answered?'bg-green-100 text-green-700':'bg-red-100 text-red-600'}">${d.answered?'Answered':'Open'}</span>
        </div>
        <p class="text-[11px] text-gray-500">${d.subject} · ${d.date}</p>
      </div>
    </div>
    <p class="text-sm text-gray-800 mt-3 leading-relaxed">${d.question}</p>
    ${d.answered?`<div class="mt-3 p-3 bg-green-50 rounded-xl border border-green-200">
      <p class="text-[11px] font-bold text-green-700 mb-1">✓ Answer</p>
      <p class="text-xs text-gray-700 leading-relaxed">${d.answer}</p>
    </div>`:isTA?`<button onclick="openAns(${d.id},\`${d.question.replace(/`/g,'').replace(/\n/g,' ')}\`)"
      class="mt-3 text-xs font-bold text-blue-700 border border-blue-200 px-3 py-1.5 rounded-full hover:bg-blue-50 active:scale-95 transition-all">Post Answer</button>`:''}
    <div class="flex items-center gap-3 mt-3 pt-2 border-t border-gray-100">
      <button onclick="voteDbt(${d.id})" class="flex items-center gap-1 text-xs text-gray-500 hover:text-blue-600 transition-colors">
        <span class="material-symbols-outlined text-[14px]">thumb_up</span>${d.votes}
      </button>
    </div>
  </div>`;
}

Router.afterRender('doubts', (_,s) => {
  const isTA = s.role==='admin'||s.role==='teacher';
  window.filterDbt = (f) => {
    ['All','Unanswered','Answered'].forEach(x=>{
      const b=document.getElementById('df-'+x);
      if(!b)return;
      b.className=b.className.replace('bg-blue-700 text-white','bg-white border border-gray-200 text-gray-600');
    });
    const sel=document.getElementById('df-'+f);
    if(sel) sel.className=sel.className.replace('bg-white border border-gray-200 text-gray-600','bg-blue-700 text-white');
    const all=DB.get('doubts');
    let filtered=all;
    if(f==='Unanswered') filtered=all.filter(d=>!d.answered);
    if(f==='Answered')   filtered=all.filter(d=>d.answered);
    document.getElementById('dbt-list').innerHTML=filtered.map(d=>doubtCard(d,isTA,s)).join('');
  };
  window.saveDbt = () => {
    const sub=document.getElementById('dbt-sub').value.trim();
    const q  =document.getElementById('dbt-q').value.trim();
    if(!sub||!q){toast('Fill all fields','err');return;}
    DB.addDoubt({studentName:s.name,subject:sub,question:q});
    toast('Doubt submitted!');
    document.getElementById('dbt-modal').classList.add('hidden');
    navigate('doubts');
  };
  window.openAns = (id,question) => {
    document.getElementById('ans-id').value=id;
    document.getElementById('ans-preview').textContent=question;
    document.getElementById('ans-modal').classList.remove('hidden');
  };
  window.postAnswer = () => {
    const id =parseInt(document.getElementById('ans-id').value);
    const ans=document.getElementById('ans-text').value.trim();
    if(!ans){toast('Write an answer first','err');return;}
    DB.answerDoubt(id,ans);
    toast('Answer posted!');
    document.getElementById('ans-modal').classList.add('hidden');
    navigate('doubts');
  };
  window.voteDbt = (id) => { DB.voteDoubt(id); navigate('doubts'); };
});

// ─── TEACHER MANAGEMENT ───────────────────────────────────────
Router.register('teachers', (_,s) => {
  if(s.role!=='admin'){ navigate('dashboard'); return ''; }
  const teachers=DB.get('teachers');
  return `
<div class="min-h-screen bg-gray-50 pb-8">
  ${topBar('Teacher Management', true)}
  <div class="p-4 space-y-4">
    <!-- Add teacher card -->
    <div class="bg-white border border-gray-100 rounded-2xl p-5 shadow-sm">
      <h2 class="font-bold text-gray-900 mb-3 flex items-center gap-2">
        <span class="material-symbols-outlined text-orange-600 text-[20px]" style="font-variation-settings:'FILL' 1">person_add</span>Add New Teacher</h2>
      <div class="space-y-3">
        ${inputField('t-name','text','Full name (e.g. Dr. Sarah Jenkins)','person')}
        ${inputField('t-email','email','Work email','alternate_email')}
        ${inputField('t-phone','tel','Phone number','call')}
        ${inputField('t-sub','text','Subject taught','menu_book')}
        <div class="relative">
          <span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-[18px]">lock</span>
          <input id="t-pass" type="text" value="Target@2024!" class="w-full h-12 pl-10 pr-12 border border-gray-200 rounded-2xl bg-gray-50 text-sm font-mono focus:border-blue-500 outline-none"/>
          <button onclick="genPass()" class="absolute right-3 top-1/2 -translate-y-1/2 p-1 rounded-full hover:bg-gray-100" title="Generate">
            <span class="material-symbols-outlined text-gray-500 text-[16px]">refresh</span></button>
        </div>
        <button onclick="saveTeacher()" class="w-full h-12 bg-orange-600 text-white font-bold rounded-2xl hover:bg-orange-700 active:scale-95 transition-all flex items-center justify-center gap-2 shadow-md">
          <span class="material-symbols-outlined text-[18px]">person_add</span>Create Teacher Account
        </button>
      </div>
    </div>

    <!-- Teachers list -->
    <div>
      <h2 class="font-bold text-gray-800 text-sm mb-2">All Teachers (${teachers.length})</h2>
      ${teachers.map(t=>`
        <div class="bg-white border border-gray-100 rounded-2xl p-3 mb-2 flex items-center gap-3 shadow-sm">
          <div class="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center flex-shrink-0">
            <span class="material-symbols-outlined text-orange-700 text-[20px]" style="font-variation-settings:'FILL' 1">person</span></div>
          <div>
            <p class="font-bold text-gray-900 text-sm">${t.name}</p>
            <p class="text-xs text-gray-500">${t.subject} · ${t.email}</p>
          </div>
        </div>`).join('')}
    </div>
  </div>
</div>`;
});
Router.afterRender('teachers', () => {
  window.genPass = () => {
    const c='ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789@#!';
    document.getElementById('t-pass').value=Array.from({length:10},()=>c[Math.floor(Math.random()*c.length)]).join('');
  };
  window.saveTeacher = () => {
    const name=document.getElementById('t-name').value.trim();
    const email=document.getElementById('t-email').value.trim();
    const phone=document.getElementById('t-phone').value.trim();
    const sub=document.getElementById('t-sub').value.trim();
    const pass=document.getElementById('t-pass').value.trim();
    if(!name||!email||!sub||!pass){toast('All fields required','err');return;}
    DB.addTeacher({name,email,phone,subject:sub,password:pass});
    toast('Teacher account created!');
    navigate('teachers');
  };
});
