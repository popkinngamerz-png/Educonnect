// ============================================================
// EduConnect Mock Database — localStorage backed
// ============================================================
const DB = {
  _seed() {
    if (localStorage.getItem('ec_seeded')) return;
    this.set('users', [
      { id:1, role:'admin',   email:'admin@edu.app',   password:'admin123', name:'Super Admin' },
      { id:2, role:'teacher', email:'teacher@edu.app', password:'teach123', name:'Dr. Sarah Jenkins', subject:'Mathematics' },
      { id:3, role:'student', email:'student@edu.app', password:'study123', name:'Arjun Sharma', class:'10A' },
    ]);
    this.set('notices', [
      { id:1, title:'Annual Science Fair', category:'Academic', body:'Students from Class 6-12 are invited to register projects for the Science Fair. Submit abstracts by end of week to the Physics Lab coordinator.', author:'Admin', date:'2026-05-28', pinned:true },
      { id:2, title:'Sports Day – June 15', category:'Sports', body:'All students must report to the ground by 8 AM. PT uniform is mandatory. Parents are welcome to attend.', author:'Admin', date:'2026-05-27', pinned:false },
      { id:3, title:'Parent-Teacher Meeting', category:'Events', body:'PTM scheduled for June 5th. Parents must carry student report cards. Meeting timings: 9 AM to 1 PM.', author:'Dr. Sarah Jenkins', date:'2026-05-25', pinned:false },
    ]);
    this.set('homework', [
      { id:1, subject:'Mathematics', title:'Quadratic Equations – Ch.4', class:'10A', dueDate:'2026-06-02', status:'Pending',   description:'Solve exercises 4.1 to 4.5 from NCERT textbook.' },
      { id:2, subject:'Science',     title:'Lab Report: Photosynthesis', class:'10A', dueDate:'2026-06-03', status:'Submitted', description:'Write a 500-word report on your photosynthesis experiment.' },
      { id:3, subject:'History',     title:'Essay: Independence Movement', class:'10B', dueDate:'2026-05-31', status:'Pending', description:'Write a 1000-word essay using MLA format.' },
      { id:4, subject:'English',     title:'Book Review – Animal Farm', class:'9A',  dueDate:'2026-06-05', status:'Pending',   description:'Write a 600-word critical book review.' },
    ]);
    this.set('doubts', [
      { id:1, studentName:'Arjun Sharma', subject:'Mathematics', question:'Can you explain the discriminant formula for quadratic equations and when each case applies?', answered:true,  answer:'The discriminant is b²-4ac. If >0: two real roots. If =0: one repeated root. If <0: no real roots (complex).', votes:5, date:'2026-05-27' },
      { id:2, studentName:'Priya Nair',   subject:'History',     question:'Are we required to use MLA format for the history essay due on Friday?', answered:false, answer:'', votes:3, date:'2026-05-28' },
      { id:3, studentName:'Rahul Mehta',  subject:'Science',     question:'What is the difference between mitosis and meiosis?', answered:false, answer:'', votes:7, date:'2026-05-29' },
    ]);
    this.set('teachers', [
      { id:1, name:'Dr. Sarah Jenkins', email:'teacher@edu.app', subject:'Mathematics', phone:'9800000001' },
    ]);
    this.set('students', [
      { id:1, name:'Arjun Sharma', email:'student@edu.app', phone:'9800000002', class:'10A' },
      { id:2, name:'Priya Nair',   email:'priya@edu.app',   phone:'9800000003', class:'10A' },
    ]);
    localStorage.setItem('ec_seeded','1');
  },
  get(k)       { try { return JSON.parse(localStorage.getItem(k)||'[]'); } catch(e){ return []; } },
  set(k,v)     { localStorage.setItem(k, JSON.stringify(v)); },
  nextId(arr)  { return arr.length ? Math.max(...arr.map(x=>x.id))+1 : 1; },
  login(e,p)   { return this.get('users').find(u=>(u.email===e||u.name===e)&&u.password===p)||null; },
  getSession() { try{ return JSON.parse(sessionStorage.getItem('ec_session')||'null'); }catch(e){return null;} },
  setSession(u){ sessionStorage.setItem('ec_session', JSON.stringify(u)); },
  clearSession(){ sessionStorage.removeItem('ec_session'); },
  addNotice(n) { const l=this.get('notices'); n.id=this.nextId(l); n.date=new Date().toISOString().split('T')[0]; l.unshift(n); this.set('notices',l); return n; },
  addHomework(h){ const l=this.get('homework'); h.id=this.nextId(l); l.unshift(h); this.set('homework',l); return h; },
  submitHomework(id){ const l=this.get('homework'); const h=l.find(x=>x.id===id); if(h)h.status='Submitted'; this.set('homework',l); },
  addDoubt(d)  { const l=this.get('doubts'); d.id=this.nextId(l); d.date=new Date().toISOString().split('T')[0]; d.answered=false; d.votes=0; l.unshift(d); this.set('doubts',l); return d; },
  answerDoubt(id,ans){ const l=this.get('doubts'); const d=l.find(x=>x.id===id); if(d){d.answered=true;d.answer=ans;} this.set('doubts',l); },
  voteDoubt(id){ const l=this.get('doubts'); const d=l.find(x=>x.id===id); if(d)d.votes=(d.votes||0)+1; this.set('doubts',l); },
  addTeacher(t){ const tl=this.get('teachers'); t.id=this.nextId(tl); tl.push(t); this.set('teachers',tl); const ul=this.get('users'); ul.push({id:this.nextId(ul),role:'teacher',email:t.email,password:t.password||'teach123',name:t.name}); this.set('users',ul); return t; },
  addStudent(s){ const sl=this.get('students'); s.id=this.nextId(sl); sl.push(s); this.set('students',sl); const ul=this.get('users'); ul.push({id:this.nextId(ul),role:'student',email:s.email,password:s.password||'study123',name:s.name}); this.set('users',ul); return s; },
};
DB._seed();
window.DB = DB;
